﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ProductsData;
using ProductsData.Entities;

namespace ProductsWedApp.Controllers
{
    public class ProductsController : Controller
    {
        private readonly ProductDbContext context;

        public ProductsController(ProductDbContext _context)
        {
            context= _context;
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public async Task<ActionResult> Create(Product product)
        {
            context.Add(product);
            await context.SaveChangesAsync();
            product.Code = product.GeneradeCode();
            context.Update(product);
            await context.SaveChangesAsync();
            return RedirectToAction("Create");
        }
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var products= await context.Products.ToListAsync();
            return View(products);
        }

        [HttpPost]
        public async Task<IActionResult> Delete(int id)
        {
            var product = await context.Products.FirstOrDefaultAsync(p=>p.Id == id);
            if (product != null)
            {
                context.Products.Remove(product);
                await context.SaveChangesAsync();
            }

            return RedirectToAction("Index");
        }

        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            var product = await context.Products.FirstOrDefaultAsync(x => x.Id == id);
            if (product == null) return NotFound();
            return View(product);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(Product product)
        {
            context.Products.Update(product);
            await context.SaveChangesAsync();

            return RedirectToAction("Index");
        }
    }
}
