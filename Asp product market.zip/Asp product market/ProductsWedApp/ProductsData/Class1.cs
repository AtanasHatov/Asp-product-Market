﻿namespace ProductsData
{
    public class Class1
    {

    }
}
