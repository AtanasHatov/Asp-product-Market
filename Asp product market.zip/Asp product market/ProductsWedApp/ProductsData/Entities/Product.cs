﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductsData.Entities
{
    public enum ProductType 
    {
        Food,
        Clothes,
        Cosmetics
    }

    public class Product
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public ProductType Type { get; set; }    
        public decimal Price { get; set; }
        public decimal Qentity { get; set; }

        public string Code { get; set; } = string.Empty;

        public string GeneradeCode()
        {
            var partname = Name;
            var parttype= Type.ToString();

            var code = $"{partname.Substring(0,2)}{parttype.Substring(0,3)}000{Id}";

            return code;
        }
    }
}
